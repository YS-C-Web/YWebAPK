// ============================================
// YSWEBAPK - SCRIPT CON ALERTAS PARA DEPURACIÓN
// ============================================

alert('🚀 Script.js cargado correctamente');

document.addEventListener('DOMContentLoaded', function() {
    alert('📄 DOM cargado');
    
    // ===== REFERENCIAS =====
    const appGrid = document.getElementById('appGrid');
    const modalOverlay = document.getElementById('modalOverlay');
    const modalBody = document.getElementById('modalBody');
    const modalClose = document.getElementById('modalClose');
    const btnComentarios = document.getElementById('btnComentarios');
    const sortSelect = document.getElementById('sortSelect');
    const quickMenu = document.getElementById('quickMenu');
    const filterLabel = document.getElementById('filterLabel');
    const resultCount = document.getElementById('resultCount');
    const infoBtn = document.getElementById('btnInfo');
    const configBtn = document.getElementById('btnConfig');
    const infoModalOverlay = document.getElementById('infoModalOverlay');
    const infoModalClose = document.getElementById('infoModalClose');
    const configModalOverlay = document.getElementById('configModalOverlay');
    const configModalClose = document.getElementById('configModalClose');
    const themeLight = document.getElementById('themeLight');
    const themeDark = document.getElementById('themeDark');
    const searchInput = document.getElementById('searchInput');
    const searchClear = document.getElementById('searchClear');
    const searchContainer = document.getElementById('searchContainer');
    const toggleSearchBtn = document.getElementById('toggleSearchBtn');
    const screenshotZoomOverlay = document.getElementById('screenshotZoomOverlay');
    const screenshotZoomImage = document.getElementById('screenshotZoomImage');
    const screenshotZoomClose = document.getElementById('screenshotZoomClose');
    const devModalOverlay = document.getElementById('devModalOverlay');
    const devModalClose = document.getElementById('devModalClose');
    const linkNotification = document.getElementById('linkNotification');
    const linkNotificationText = document.getElementById('linkNotificationText');

    let currentFilter = 'all';
    let currentSearch = '';
    let searchVisible = false;

    // ===== VERIFICAR APPS_DATA =====
    if (typeof APPS_DATA === 'undefined') {
        alert('❌ APPS_DATA NO ESTÁ DEFINIDO');
        window.APPS_DATA = [];
    } else {
        alert('✅ APPS_DATA cargado con ' + APPS_DATA.length + ' apps');
        // Mostrar los nombres de las apps
        let nombres = '';
        APPS_DATA.forEach(function(app, i) {
            nombres += (i+1) + '. ' + app.nombre + ' (ID:' + app.id + ')\n';
        });
        alert('📱 Apps disponibles:\n' + nombres);
    }

    // ===== TEMA OSCURO/CLARO =====
    function loadTheme() {
        const theme = localStorage.getItem('yswebapk_theme') || 'light';
        if (theme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
            if (themeDark) themeDark.classList.add('active');
            if (themeLight) themeLight.classList.remove('active');
        } else {
            document.documentElement.removeAttribute('data-theme');
            if (themeLight) themeLight.classList.add('active');
            if (themeDark) themeDark.classList.remove('active');
        }
    }

    function setTheme(theme) {
        localStorage.setItem('yswebapk_theme', theme);
        loadTheme();
    }

    loadTheme();

    if (themeLight) themeLight.addEventListener('click', () => setTheme('light'));
    if (themeDark) themeDark.addEventListener('click', () => setTheme('dark'));

    // ===== CONFIGURACIÓN =====
    if (configBtn) {
        configBtn.addEventListener('click', function() {
            if (configModalOverlay) {
                configModalOverlay.classList.add('open');
                document.body.style.overflow = 'hidden';
            }
        });
    }

    if (configModalClose) {
        configModalClose.addEventListener('click', function() {
            if (configModalOverlay) {
                configModalOverlay.classList.remove('open');
                document.body.style.overflow = '';
            }
        });
    }

    if (configModalOverlay) {
        configModalOverlay.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('open');
                document.body.style.overflow = '';
            }
        });
    }

    // ===== TOGGLE BUSCADOR =====
    function toggleSearch() {
        searchVisible = !searchVisible;
        if (searchVisible) {
            if (searchContainer) searchContainer.classList.add('visible');
            if (toggleSearchBtn) {
                toggleSearchBtn.classList.add('active-btn');
                toggleSearchBtn.innerHTML = '<i class="fas fa-times"></i> Cerrar';
            }
            setTimeout(() => searchInput?.focus(), 400);
        } else {
            if (searchContainer) searchContainer.classList.remove('visible');
            if (toggleSearchBtn) {
                toggleSearchBtn.classList.remove('active-btn');
                toggleSearchBtn.innerHTML = '<i class="fas fa-search"></i> Buscar';
            }
            if (searchInput) {
                searchInput.value = '';
                currentSearch = '';
                if (searchClear) searchClear.classList.remove('visible');
                renderGrid(currentFilter, sortSelect?.value || 'nombre', currentSearch);
            }
        }
    }

    if (toggleSearchBtn) {
        toggleSearchBtn.addEventListener('click', toggleSearch);
    }

    // ===== FUNCIÓN DE PRUEBA PARA ABRIR MODAL =====
    window.testAbrirModal = function(id) {
        alert('🔘 testAbrirModal llamado con ID: ' + id);
        openModal(id);
    };

    // ===== RENDER GRID =====
    function renderGrid(filter = 'all', sortKey = 'nombre', search = '') {
        alert('📋 renderGrid - Total apps: ' + APPS_DATA.length + ', Filtro: ' + filter);
        
        let filtered = [...APPS_DATA];

        if (filter !== 'all') {
            filtered = filtered.filter(a => a.categoria === filter);
        }

        if (search.trim() !== '') {
            const term = search.trim().toLowerCase();
            filtered = filtered.filter(a => {
                return (a.nombre || '').toLowerCase().includes(term) ||
                       (a.categoria || '').toLowerCase().includes(term) ||
                       (a.descripcion || '').toLowerCase().includes(term);
            });
        }

        const sorted = [...filtered];
        if (sortKey === 'nombre') sorted.sort((a,b) => (a.nombre || '').localeCompare(b.nombre || ''));
        else if (sortKey === 'fecha') sorted.sort((a,b) => new Date(b.fecha || 0) - new Date(a.fecha || 0));
        else if (sortKey === 'tamaño') {
            sorted.sort((a,b) => {
                const numA = parseFloat(a.tamaño) || 0;
                const numB = parseFloat(b.tamaño) || 0;
                return numA - numB;
            });
        } else if (sortKey === 'categoria') sorted.sort((a,b) => (a.categoria || '').localeCompare(b.categoria || ''));
        else if (sortKey === 'descargas') sorted.sort((a,b) => (b.descargas || 0) - (a.descargas || 0));

        if (sorted.length === 0) {
            if (appGrid) {
                appGrid.innerHTML = `<div style="grid-column:1/-1; text-align:center; padding:2rem; color:var(--text-secondary);">
                    <i class="fas fa-search" style="font-size:2rem; display:block; margin-bottom:0.5rem;"></i>
                    No se encontraron APKs
                </div>`;
            }
            if (resultCount) resultCount.textContent = '0';
            return;
        }
        if (resultCount) resultCount.textContent = sorted.length;

        const catMap = {
            'all': 'Todos',
            'juego': 'Juegos',
            'utilidad': 'Utilidades',
            'educación': 'Educación',
            'social': 'Social',
            'entretenimiento': 'Entretenimiento'
        };
        if (filterLabel) filterLabel.textContent = catMap[filter] || filter;

        let html = '';
        sorted.forEach(app => {
            const dev = app.enDesarrollo === true || app.id === '#';
            const devClass = dev ? 'dev-mode' : '';
            const devBadge = dev ? `<span class="dev-badge">🚧 Desarrollo</span>` : '';
            const devText = dev ? `<div class="app-dev-text">En desarrollo</div>` : '';
            const authorText = app.creador_id ? `<div class="app-author">👤 Desarrollador</div>` : '';

            let iconHtml = '';
            if (app.icono && app.icono !== '') {
                iconHtml = `<img src="${app.icono}" alt="icono" onerror="this.style.display='none'; this.parentElement.innerHTML='<i class=\\'fas fa-cube\\'></i>';">`;
            } else {
                iconHtml = '<i class="fas fa-cube"></i>';
            }

            // AÑADIR onclick DIRECTAMENTE EN LA TARJETA
            html += `
                <div class="app-card ${devClass}" data-id="${app.id}" data-dev="${dev}" onclick="testAbrirModal(${app.id})">
                    ${devBadge}
                    <div class="app-icon">${iconHtml}</div>
                    <div class="app-name">${app.nombre || 'Sin nombre'}</div>
                    <div class="app-version">v${app.version || '1.0'}</div>
                    <div class="app-category">${catMap[app.categoria] || app.categoria || 'Sin categoría'}</div>
                    ${devText}
                    ${authorText}
                </div>
            `;
        });
        if (appGrid) appGrid.innerHTML = html;
        
        alert('✅ Grid renderizado con ' + sorted.length + ' tarjetas');
    }

    // ===== ABRIR MODAL APK (VERSIÓN CORREGIDA CON ALERTAS) =====
    function openModal(appId) {
        alert('🔍 openModal llamado con ID: ' + appId);
        
        // Buscar la app en APPS_DATA
        alert('🔎 Buscando en APPS_DATA...');
        const app = APPS_DATA.find(a => a.id == appId);
        
        if (!app) {
            alert('❌ APK NO ENCONTRADA con ID: ' + appId);
            showNotification('❌ APK no encontrada');
            return;
        }
        
        alert('✅ App encontrada: ' + app.nombre + ' (ID: ' + app.id + ')');

        if (app.enDesarrollo === true || app.id === '#') {
            alert('📌 App en desarrollo, abriendo modal de desarrollo');
            openDevModal(app);
            return;
        }

        alert('📱 Abriendo modal para: ' + app.nombre);

        let screenshotsHtml = '';
        if (app.screenshots) {
            let screenshots = [];
            try {
                if (typeof app.screenshots === 'string') {
                    screenshots = JSON.parse(app.screenshots);
                } else if (Array.isArray(app.screenshots)) {
                    screenshots = app.screenshots;
                }
            } catch(e) {
                screenshots = [];
            }
            
            if (screenshots.length > 0 && screenshots[0] !== '') {
                screenshotsHtml = screenshots.map(s => 
                    `<img src="${s}" alt="screenshot" data-screenshot="${s}" class="screenshot-thumb" loading="lazy" style="height:130px;width:auto;border-radius:12px;border:2px solid var(--border-color);cursor:pointer;">`
                ).join('');
            } else {
                screenshotsHtml = '<span style="color:var(--text-secondary);font-size:0.8rem;">Sin capturas</span>';
            }
        } else {
            screenshotsHtml = '<span style="color:var(--text-secondary);font-size:0.8rem;">Sin capturas</span>';
        }

        let iconHtml = '';
        if (app.icono && app.icono !== '') {
            iconHtml = `<img src="${app.icono}" alt="icono" onerror="this.style.display='none'; this.parentElement.innerHTML='<i class=\\'fas fa-cube\\'></i>';">`;
        } else {
            iconHtml = '<i class="fas fa-cube"></i>';
        }

        const link = app.link || '#';
        const downloadLink = link !== '#' && link !== 'apks/' && link !== 'apks' ? `descargas.php?id=${app.id}` : '#';
        const isDisabled = link === '#' || link === 'apks/' || link === 'apks';

        if (!modalBody) {
            alert('❌ modalBody NO ENCONTRADO');
            return;
        }

        modalBody.innerHTML = `
            <div style="display:flex;flex-direction:column;">
                <div class="modal-icon">${iconHtml}</div>
                <div class="modal-title">${app.nombre || 'Sin nombre'}</div>
                <div class="modal-meta">
                    <span><i class="fas fa-tag"></i> ${app.categoria || 'Sin categoría'}</span>
                    <span><i class="fas fa-code-branch"></i> v${app.version || '1.0'}</span>
                    <span><i class="fas fa-hdd"></i> ${app.tamaño || '0 MB'}</span>
                    <span><i class="fas fa-calendar-alt"></i> ${app.fecha || 'N/A'}</span>
                    <span><i class="fas fa-download"></i> ${app.descargas || 0} descargas</span>
                </div>
                <div class="modal-desc">${app.descripcion || 'Sin descripción'}</div>
                <div class="modal-screenshots">${screenshotsHtml}</div>
                <a href="${downloadLink}" class="download-btn ${isDisabled ? 'disabled' : ''}" 
                   onclick="return handleDownload('${link}', this);">
                    <i class="fas fa-download"></i> Descargar APK<br>
                    ${app.nombre || 'APK'} V${app.version || '1.0'}.apk
                </a>
            </div>
        `;

        alert('📋 HTML del modal generado');

        // Evento para hacer zoom en capturas
        document.querySelectorAll('.screenshot-thumb').forEach(img => {
            img.addEventListener('click', function(e) {
                e.stopPropagation();
                const src = this.dataset.screenshot;
                if (src) openScreenshotZoom(src);
            });
        });

        if (btnComentarios) {
            btnComentarios.style.display = 'block';
            btnComentarios.onclick = function() {
                closeModal();
                window.location.href = `apk-detalle.php?id=${app.id}`;
            };
        }

        if (modalOverlay) {
            modalOverlay.classList.add('open');
            document.body.style.overflow = 'hidden';
            alert('✅ Modal abierto correctamente');
        } else {
            alert('❌ modalOverlay NO ENCONTRADO');
        }
    }

    function closeModal() {
        if (modalOverlay) {
            modalOverlay.classList.remove('open');
            document.body.style.overflow = '';
        }
        if (btnComentarios) {
            btnComentarios.style.display = 'none';
        }
    }

    // ===== ABRIR APP POR NOMBRE =====
    function openAppByName(appName) {
        alert('🔍 Buscando app por nombre: ' + appName);
        const app = APPS_DATA.find(a => (a.nombre || '').toLowerCase() === appName.toLowerCase());
        if (app) {
            showNotification(`📱 Abriendo: ${app.nombre}`);
            setTimeout(() => {
                openModal(app.id);
            }, 400);
            return true;
        } else {
            showNotification(`❌ No se encontró: "${appName}"`);
            return false;
        }
    }

    // ===== NOTIFICACIÓN =====
    let notificationTimeout = null;

    function showNotification(message) {
        if (linkNotificationText) linkNotificationText.textContent = message;
        if (linkNotification) linkNotification.classList.add('show');
        
        if (notificationTimeout) {
            clearTimeout(notificationTimeout);
        }
        
        notificationTimeout = setTimeout(() => {
            if (linkNotification) linkNotification.classList.remove('show');
        }, 3000);
    }

    // ===== MODAL "EN DESARROLLO" =====
    function openDevModal(app) {
        alert('🚧 Abriendo modal de desarrollo para: ' + app.nombre);
        const devInfoContent = document.getElementById('devInfoContent');
        if (devInfoContent) {
            devInfoContent.innerHTML = `
                <p><i class="fas fa-spinner fa-pulse"></i> <strong>${app.nombre || 'Sin nombre'}</strong> aún no está disponible.</p>
                <p style="margin-top: 0.5rem; font-size: 0.9rem; color: var(--text-secondary);">${app.descripcion || 'Sin descripción'}</p>
                <p style="margin-top: 0.5rem; font-size: 0.85rem; color: var(--text-secondary);">
                    <i class="fas fa-code-branch"></i> Versión ${app.version || '1.0'} · 
                    <i class="fas fa-calendar-alt"></i> ${app.fecha || 'N/A'}
                </p>
                <p style="margin-top: 0.5rem; font-size: 0.8rem; color: var(--warning);">
                    <i class="fas fa-hard-hat"></i> Próximamente disponible
                </p>
            `;
        }
        if (devModalOverlay) {
            devModalOverlay.classList.add('open');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeDevModal() {
        if (devModalOverlay) {
            devModalOverlay.classList.remove('open');
            document.body.style.overflow = '';
        }
    }

    // ===== ZOOM DE CAPTURA =====
    function openScreenshotZoom(src) {
        if (screenshotZoomImage) screenshotZoomImage.src = src;
        if (screenshotZoomOverlay) {
            screenshotZoomOverlay.classList.add('open');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeScreenshotZoom() {
        if (screenshotZoomOverlay) {
            screenshotZoomOverlay.classList.remove('open');
            document.body.style.overflow = '';
            setTimeout(() => {
                if (!screenshotZoomOverlay.classList.contains('open')) {
                    if (screenshotZoomImage) screenshotZoomImage.src = '';
                }
            }, 300);
        }
    }

    // ===== MODAL INFORMACIÓN =====
    function openInfoModal() {
        if (infoModalOverlay) {
            infoModalOverlay.classList.add('open');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeInfoModal() {
        if (infoModalOverlay) {
            infoModalOverlay.classList.remove('open');
            document.body.style.overflow = '';
        }
    }

    if (infoBtn) infoBtn.addEventListener('click', openInfoModal);
    if (infoModalClose) infoModalClose.addEventListener('click', closeInfoModal);
    if (infoModalOverlay) {
        infoModalOverlay.addEventListener('click', function(e) {
            if (e.target === this) closeInfoModal();
        });
    }

    // ===== EVENTOS =====
    if (modalClose) modalClose.addEventListener('click', closeModal);
    if (modalOverlay) {
        modalOverlay.addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });
    }

    if (devModalClose) devModalClose.addEventListener('click', closeDevModal);
    if (devModalOverlay) {
        devModalOverlay.addEventListener('click', function(e) {
            if (e.target === this) closeDevModal();
        });
    }

    if (screenshotZoomClose) screenshotZoomClose.addEventListener('click', closeScreenshotZoom);
    if (screenshotZoomOverlay) {
        screenshotZoomOverlay.addEventListener('click', function(e) {
            if (e.target === this) closeScreenshotZoom();
        });
    }

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
            closeDevModal();
            closeInfoModal();
            closeScreenshotZoom();
            if (searchVisible) toggleSearch();
        }
    });

    // ===== MENÚ RÁPIDO =====
    if (quickMenu) {
        quickMenu.addEventListener('click', function(e) {
            const btn = e.target.closest('button');
            if (!btn) return;
            const filter = btn.dataset.filter;
            if (!filter) return;
            quickMenu.querySelectorAll('button').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentFilter = filter;
            renderGrid(currentFilter, sortSelect?.value || 'nombre', currentSearch);
        });
    }

    // ===== ORDENAR =====
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            renderGrid(currentFilter, this.value, currentSearch);
        });
    }

    // ===== BUSCADOR =====
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            currentSearch = this.value;
            if (currentSearch.length > 0) {
                if (searchClear) searchClear.classList.add('visible');
            } else {
                if (searchClear) searchClear.classList.remove('visible');
            }
            renderGrid(currentFilter, sortSelect?.value || 'nombre', currentSearch);
        });
    }

    if (searchClear) {
        searchClear.addEventListener('click', function() {
            if (searchInput) {
                searchInput.value = '';
                currentSearch = '';
                searchClear.classList.remove('visible');
                renderGrid(currentFilter, sortSelect?.value || 'nombre', currentSearch);
                searchInput.focus();
            }
        });
    }

    // ===== INICIALIZAR =====
    alert('🔄 Inicializando renderGrid...');
    renderGrid('all', 'nombre', '');

    // ===== PROCESAR PARÁMETROS DE URL =====
    function processUrlParams() {
        const urlParams = new URLSearchParams(window.location.search);
        const appParam = urlParams.get('app');
        if (appParam) {
            const appName = decodeURIComponent(appParam);
            setTimeout(() => {
                openAppByName(appName);
            }, 500);
        }
    }
    processUrlParams();

    // ===== FUNCIÓN GLOBAL PARA DESCARGA =====
    window.handleDownload = function(link, btn) {
        if (btn.dataset.loading === 'true') return false;
        if (!link || link === '#' || link === 'apks/' || link === 'apks') {
            showNotification('❌ Enlace de descarga no disponible');
            return false;
        }

        btn.dataset.loading = 'true';
        const originalHtml = btn.innerHTML;

        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Procesando descarga...';
        btn.style.opacity = '0.7';
        btn.style.pointerEvents = 'none';
        btn.classList.add('disabled');

        setTimeout(function() {
            btn.innerHTML = originalHtml;
            btn.style.opacity = '1';
            btn.style.pointerEvents = 'auto';
            btn.classList.remove('disabled');
            btn.dataset.loading = 'false';
        }, 5000);

        return true;
    };
    
    alert('✅ Script.js inicializado completamente');
});
function testAbrirModal(id) {
    alert('testAbrirModal llamado con ID: ' + id);
    openModal(id);
};

// ===== FUNCIONES GLOBALES =====
window.openModal = openModal;
window.closeModal = closeModal;
window.openScreenshotZoom = openScreenshotZoom;
window.closeScreenshotZoom = closeScreenshotZoom;
window.openDevModal = openDevModal;
window.closeDevModal = closeDevModal;
window.showNotification = showNotification;
window.handleDownload = window.handleDownload;
window.testAbrirModal = testAbrirModal;